from django.apps import AppConfig


class KingappConfig(AppConfig):
    name = 'kingapp'
