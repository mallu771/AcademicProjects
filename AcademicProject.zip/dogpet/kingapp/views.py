from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib.auth.models import User,auth
#from django.contrib.auth.models import User,auth
#from .models import Contact
#from.models import MyClass

# Create your views here.
def home(request):
    #myclass=MyClass.objects.all()
   
   # return render(request,'index.html',{'myclass':myclass})
    return render(request,'index.html')
def about(request):
    return render(request,'about.html')
    
def gallery(request):
    return render(request,'gallery.html')


# Create your views here.
def register(request):
    if request.method=='POST':
        fname=request.POST['fname']
        lname=request.POST['lname']
        uname=request.POST['uname']
        email=request.POST['email']
        psw=request.POST['psw']
        pswrepeat=request.POST['pswrepeat']
        
        if psw==pswrepeat:
            if User.objects.filter(username=uname).exists():
                print("Username Taken")
            elif User.objects.filter(email=email).exists():
                print("Email Taken")
            else:   
                user=User.objects.create_user(username=uname,password=psw,first_name=fname,last_name=lname,email=email)
                user.save()
                print('user create')
                return redirect('/')
                
                
        else:
            print("Password not Matching")
            return redirect('/')
            
    else:
        return render(request,'register.html')