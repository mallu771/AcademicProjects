from django.shortcuts import render,redirect
from .models import Admin
# Create your views here.

def details(request):
    if request.method == 'POST':
        fname=request.POST['fname']
        lname=request.POST['lname']
        num=request.POST['no']
        message=request.POST['message']
        
        emp=Admin.objects.create(fname=fname,lname=lname,no=num,message=message)
        emp.save()
        print("Data created")
        return redirect('/')
        
    else:
        return render(request,'contact.html')
        